
export const STORED_KEY = 'CONVERSATION_STORED_KEY'
export const STORAGE_ACCESS_TOKEN = 'STORAGE_ACCESS_TOKEN'
export const CHATGPT_DEFAULT_AVATAR = 'https://mtbird-cdn.staringos.com/product/images/chatgpt.png'
export const ASSISTANT_NAME = 'ASSISTANT_NAME'